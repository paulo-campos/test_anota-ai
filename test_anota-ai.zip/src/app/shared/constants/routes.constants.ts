export const ROUTES = {
  HOME: 'home'
};

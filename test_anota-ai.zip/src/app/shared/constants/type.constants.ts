export const TYPES = {
  '1': {
    color: '#0059FB',
    label: 'Paisagem'
  },
  '2': {
    color: '#FF004B',
    label: 'Flor'
  },
  '3': {
    color: '#918C01',
    label: 'Pizza'
  }
};

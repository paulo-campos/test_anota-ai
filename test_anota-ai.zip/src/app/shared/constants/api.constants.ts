export const API = {
  LIST: 'https://githubanotaai.github.io/frontend-interview-mock-data/cardlist.json'
};

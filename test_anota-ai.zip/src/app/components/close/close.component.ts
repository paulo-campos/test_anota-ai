import { Component } from '@angular/core';

@Component({
  selector: 'app-close',
  templateUrl: './close.component.html',
  styleUrl: './close.component.scss',
  standalone: true
})
export class CloseComponent {}
